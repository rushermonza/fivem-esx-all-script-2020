# fxserver-esx_sit

### Warning: This resource is not actively maintained. The ESX Teams has higher priorties than this particular add-on, if you have a suggestion open a PR. The likelihood of the ESX Team making feature based updates to esx_sit are unlikely. Thanks for understanding!

This script allow you to sit almost everywhere.
If the player has many props around him, the game camera might become crazy.

SHIFT + E to sit, gamepad protected so player can't interact with gamepads.

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/FXServer-ESX/fxserver-esx_sit esx_sit
```
3) Add this in your server.cfg :
```
start esx_sit
```
[CREDITS]

- Original code by CmJustice https://github.com/CmJustice
