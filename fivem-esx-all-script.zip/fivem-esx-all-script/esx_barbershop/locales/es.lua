Locales['es'] = {
  ['valid_purchase'] = '¿validar esta compra?',
  ['yes'] = 'si',
  ['no'] = 'no',
  ['not_enough_money'] = 'no tienes suficente dinero',
  ['press_access'] = 'presiona ~INPUT_CONTEXT~ para acceder al menú',
  ['barber_blip'] = 'barbero',
  ['you_paid'] = 'has pagado $%s',
}
