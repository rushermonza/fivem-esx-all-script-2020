Locales['fr'] = {

	['veh_released'] = 'véhicule ~g~sorti',
	['veh_stored'] = 'véhicule ~g~rangé',
	['veh_health'] = 'vous devez d\'abord réparer votre véhicule!',
}
