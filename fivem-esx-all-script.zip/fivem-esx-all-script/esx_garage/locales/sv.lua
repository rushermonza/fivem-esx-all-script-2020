Locales['sv'] = {
	['veh_released'] = 'fordonet har ~y~släppts~s~ från ditt garage',
	['veh_stored'] = 'fordonet har ~g~lagrats~s~ i ditt garage',
	['veh_health'] = 'fordonet är i ett dåligt skick för att lämnas i garage.',
}
