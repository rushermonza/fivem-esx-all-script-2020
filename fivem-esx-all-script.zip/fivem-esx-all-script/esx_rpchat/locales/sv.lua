Locales['sv'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'skicka en tweet',
  ['twt_prefix'] = '^5@%s^0',
  ['me_help'] = 'skriv en händelse, t.ex \'visar körkort\'',
  ['me_prefix'] = 'jag | %s',
  ['do_help'] = 'något karaktären gör inom rollspel',
  ['do_prefix'] = 'gör | %s',
  ['generic_argument_name'] = 'meddelande',
  ['generic_argument_help'] = 'det meddelandet du vill skicka',
  ['unknown_command'] = '^3%s^0 är inte ett giltigt kommando!',
}
